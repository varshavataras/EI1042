<nav>
	<ul>
		<li>
			<a href="?action=home">Home</a>
		</li>
		<li>
			<a href="?action=crearTabla">CrearTabla</a>
		</li>
		<li>
			<a href="?action=registro">Registro</a>
		</li>

		<li>
			<a href="?action=listar">Listar</a>
		</li>
		<li>
			<a href="../holaMundo.php">HolaMundo</a>
		</li>
	</ul>
</nav>